from tkinter import*


root = Tk()

e = Entry(root,width=50)
e.pack()

def myClick():
    hello = e.get()
    myLabel = Label(root, text=hello)
    myLabel.pack()


myButton = Button(root, text= "Enter your name", command=myClick, fg="blue", bg="red" )
myButton.pack()

root.mainloop()