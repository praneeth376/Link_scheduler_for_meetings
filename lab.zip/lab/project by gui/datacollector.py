import sqlite3
import webbrowser
import time 

links=[]
alarms=[]
conn=sqlite3.connect("linkscheduler.db")
c = conn.cursor()
c.execute('''SELECT link, time FROM linkscheduler;''')
columns = c.fetchall()
for row in columns:
    links.append(row[0])
    alarms.append(row[1])

i=0
while i<len(links):
    link=links[i]
    alarm=alarms[i]
    Current_time = time.strftime("%H:%M:%S") 
    print("The Given Link should be Open at ",alarm)
    # Printing current time untill alarm time
    while (Current_time != alarm): 
       print ("Waiting, the current time is " + Current_time +" :-( " )
       Current_time = time.strftime("%H:%M:%S") 
       time.sleep(1) 

    # Opening the webpage at alarm time
    if (Current_time == alarm): 
       print ("WEBSITE IS OPENING :D") 
       webbrowser.open(link)
    i=i+1