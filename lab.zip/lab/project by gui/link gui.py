from tkinter import*
import sqlite3

root = Tk()

e = Entry(root,width=50)
e.grid(row=0, column=0, columnspan=3, padx= 10, pady= 10)
e1 = Entry(root,width=50)
e1.grid(row=1, column=0, columnspan=3, padx= 10, pady= 10)
l=[]
lst=[]
def mylink():
    hello = e.get()
    world = e1.get()
    #myLabel = Label(root, text=hello + world)
    #myLabel.pack()
    l.append(hello)
    lst.append(world)
    print(l)
    print(lst)

    conn=sqlite3.connect("linkscheduler.db")
    c = conn.cursor()
    c.execute("CREATE TABLE IF NOT EXISTS linkscheduler(link text,time text)")

    c.execute("INSERT INTO linkscheduler VALUES (:link,:time)",
        {
            'link' : e.get(),
            'time' : e1.get()
        }            
        )
    conn.commit()
    conn.close()

linkButton = Button(root, text= "Enter link and time", padx= 40, pady= 10, command=mylink, fg="blue", bg="red" )
linkButton.grid(row=2, column=0, columnspan=3, padx= 10, pady= 10)

#timeButton = Button(root, text= "Enter your time", padx= 40, pady= 10, command=mytime, fg="red", bg="blue" )
#timeButton.grid(row=4, column=0)

root.mainloop()

